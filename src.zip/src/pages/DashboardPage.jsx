import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { projectApi, resumeApi, membershipApi } from '../lib/api';
// 브라우저 알림 발송
const sendNotification = (title, body) => {
  const originalTitle = document.title;
  document.title = `✅ ${title}`;
  setTimeout(() => { document.title = originalTitle; }, 5000);
  
  if ('Notification' in window && Notification.permission === 'granted') {
    const notification = new Notification(title, {
      body: body,
      icon: '/logo192.png',
      tag: 'deepgl-notification',
      requireInteraction: false,
    });
    notification.onclick = () => { window.focus(); notification.close(); };
    setTimeout(() => { notification.close(); }, 5000);
  }
};

// 알림 권한 요청
const requestNotificationPermission = async () => {
  if (!('Notification' in window)) return 'denied';
  if (Notification.permission === 'granted') return 'granted';
  if (Notification.permission !== 'denied') {
    return await Notification.requestPermission();
  }
  return Notification.permission;
};
const DashboardPage = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);
  const [showRateLimitModal, setShowRateLimitModal] = useState(false);
  const [showMembershipInfo, setShowMembershipInfo] = useState(false);
      const [resumes, setResumes] = useState([]);

  const { userId, email, signOut } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const loadData = async () => {
      if (!userId) return;
      
      try {
        setLoading(true);
        const [projectsData, resumesData] = await Promise.all([
          projectApi.getList(userId),
          resumeApi.getList(userId)
        ]);
        setProjects(projectsData.projects || []);
        setResumes(resumesData.resumes || []);
      } catch (err) {
        console.error('데이터 로드 실패:', err);
        setError('데이터를 불러오는데 실패했습니다.');
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [userId]);

  const handleLogout = async () => {
    await signOut();
    navigate('/login');
  };

  const handleProjectClick = (projectId) => {
    navigate(`/project/${projectId}`);
  };

  const handleDeleteProject = async (e, projectId) => {
    e.stopPropagation();
    if (!window.confirm('정말 삭제하시겠습니까?')) return;

    try {
      await projectApi.delete(projectId, userId);
      setProjects(projects.filter(p => p.id !== projectId));
    } catch (err) {
      setError('삭제에 실패했습니다.');
    }
  };

  const getStatusText = (status) => {
    const statusMap = {
      'draft': '초안',
      'analyzing': '분석 중',
      'analyzed': '분석 완료',
      'in_progress': '진행 중',
      'done': '완료'
    };
    return statusMap[status] || '진행 중';
  };

  return (
    <div className="dashboard-layout">
      <aside className="dashboard-sidebar">
        <div className="sidebar-profile" onClick={() => navigate('/mypage')}>
          <div className="profile-avatar">
            {email ? email[0].toUpperCase() : 'U'}
          </div>
        </div>
        <div className="sidebar-spacer" />
        <button className="sidebar-logout" onClick={() => navigate('/search')} title="검색" style={{ marginBottom: '12px' }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8" />
            <path d="M21 21l-4.35-4.35" />
          </svg>
        </button>
        <button className="sidebar-logout" onClick={() => navigate('/database')} title="데이터베이스" style={{ marginBottom: '12px' }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <ellipse cx="12" cy="5" rx="9" ry="3" />
            <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
            <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
          </svg>
        </button>
        <button className="sidebar-logout" onClick={handleLogout} title="로그아웃">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
            <polyline points="16,17 21,12 16,7" />
            <line x1="21" y1="12" x2="9" y2="12" />
          </svg>
        </button>
      </aside>
      <main className="dashboard-main">
        <div className="dashboard-header">
        <h1>My <span translate="no">DeepGL</span></h1>
                  <p className="dashboard-subtitle">자기소개서 프로젝트를 관리하세요</p>
        </div>

        {error && (
          <div className="dashboard-error">
            {error}
            <button onClick={() => setError('')}>×</button>
          </div>
        )}

        {loading ? (
          <div className="dashboard-loading">
            <div className="loading-spinner" />
            <p>프로젝트 불러오는 중...</p>
          </div>
        ) : (
          <div className="project-grid">
            <div
              className="project-card new-project-card"
              onClick={() => {
                const recentProject = projects.find(p => {
                  const created = new Date(p.created_at || p.createdAt);
                  return (Date.now() - created.getTime()) < 24 * 60 * 60 * 1000;
                });
                if (recentProject) {
                  setShowRateLimitModal(true);
                } else {
                  setShowNewProjectModal(true);
                }
              }}            >
              <div className="new-project-logo">
                <svg width="80" height="80" viewBox="0 0 200 200">
                  <defs>
                    <linearGradient id="newProjectGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#9CA3AF" stopOpacity="0.3"/>
                      <stop offset="100%" stopColor="#6B7280" stopOpacity="0.3"/>
                    </linearGradient>
                  </defs>
                  <circle cx="100" cy="100" r="80" fill="url(#newProjectGradient)" stroke="rgba(107, 114, 128, 0.5)" strokeWidth="2"/>
                  <rect x="92" y="40" width="16" height="120" fill="rgba(74, 85, 104, 0.8)" rx="8"/>
                  <rect x="40" y="92" width="120" height="16" fill="rgba(74, 85, 104, 0.8)" rx="8"/>
                </svg>
                <div className="pulse-ring pulse-ring-1"></div>
                <div className="pulse-ring pulse-ring-2"></div>
                <div className="pulse-ring pulse-ring-3"></div>
              </div>
              <span className="new-project-text">새 딥글</span>
            </div>

            {projects.map((project) => (
              <div
                key={project.id}
                className="project-card"
                onClick={() => handleProjectClick(project.id)}
              >
                <div className="project-card-header">
                  <h3 className="project-title">{project.company} / {project.jobTitle}</h3>
                  <button
                    className="project-delete-btn"
                    onClick={(e) => handleDeleteProject(e, project.id)}
                    title="삭제"
                  >
                    ×
                  </button>
                </div>
             
              </div>
            ))}
          </div>
        )}
      </main>

      {showNewProjectModal && (
       <NewProjectModal
       userId={userId}
       resumes={resumes}
       onClose={() => setShowNewProjectModal(false)}
       onRateLimit={() => {
         setShowNewProjectModal(false);
         setShowRateLimitModal(true);
       }}
       onCreated={(newProject) => {
            setProjects([...projects, newProject]);
            setShowNewProjectModal(false);
            navigate(`/project/${newProject.id}`);
          }}
        />
      )}

      {showRateLimitModal && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          background: 'rgba(0,0,0,0.5)', display: 'flex',
          alignItems: 'center', justifyContent: 'center', zIndex: 9999
        }}>
          <div style={{
            background: '#fff', borderRadius: '20px', padding: '36px',
            maxWidth: '420px', width: '90%', textAlign: 'center',
            boxShadow: '0 8px 32px rgba(0,0,0,0.12)'
          }}>
            <div style={{ marginBottom: '16px', display: 'flex', justifyContent: 'center' }}>
              <svg width="56" height="56" viewBox="0 0 200 200">
                <circle cx="100" cy="100" r="80" fill="rgba(156,163,175,0.15)" stroke="rgba(107,114,128,0.3)" strokeWidth="3" />
                <rect x="92" y="40" width="16" height="120" fill="rgba(74,85,104,0.7)" rx="8" />
                <rect x="40" y="92" width="120" height="16" fill="rgba(74,85,104,0.7)" rx="8" />
              </svg>
            </div>
            <h3 style={{ fontSize: '18px', fontWeight: 700, marginBottom: '8px', color: '#1D1D1F' }}>
              일일 생성 한도 도달
            </h3>
            <p style={{ fontSize: '14px', color: '#6E6E73', lineHeight: 1.7, marginBottom: '8px', wordBreak: 'keep-all' }}>
              일반회원은 24시간 내 프로젝트를 1개만 생성할 수 있습니다.
            </p>
            {showMembershipInfo && (
              <p style={{ fontSize: '14px', color: '#6E6E73', lineHeight: 1.7, marginBottom: '24px', wordBreak: 'keep-all' }}>
                멤버십을 희망하시면 hyochanggongwon@naver.com으로 문의주세요.
              </p>
            )}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {!showMembershipInfo && (
                <button
                  onClick={() => {
                    membershipApi.recordInquiry(userId).catch(() => {});
                    setShowMembershipInfo(true);
                  }}
                  style={{
                    display: 'block', width: '100%', padding: '14px 20px', borderRadius: '12px',
                    background: '#1D1D1F', color: '#fff', fontSize: '14px',
                    fontWeight: 600, border: 'none', cursor: 'pointer'
                  }}
                >
                  Becoming a Member
                </button>
              )}
              <button
                onClick={() => { setShowRateLimitModal(false); setShowMembershipInfo(false); }}
                style={{
                  padding: '14px 20px', borderRadius: '12px',
                  background: 'transparent', border: '1px solid rgba(0,0,0,0.08)',
                  color: '#6E6E73', fontSize: '14px', fontWeight: 500, cursor: 'pointer'
                }}
              >
                닫기
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// 새 프로젝트 생성 모달
const NewProjectModal = ({ userId, resumes, onClose, onRateLimit, onCreated }) => {
    const [step, setStep] = useState(1); // 1: 입력, 2: 분석 중
  const [loadingMessage, setLoadingMessage] = useState('');
  const [formData, setFormData] = useState({
    company: '',
    jobTitle: '',
    jobTasks: '',
    jobRequirements: '',
    jobPostingRaw: '',
    resumeId: '',
    questions: [{ text: '', wordLimit: '1000' }]
  });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleQuestionChange = (index, field, value) => {
    const newQuestions = [...formData.questions];
    newQuestions[index][field] = value;
    setFormData(prev => ({ ...prev, questions: newQuestions }));
  };

  const addQuestion = () => {
    setFormData(prev => ({
      ...prev,
      questions: [...prev.questions, { text: '', wordLimit: '1000' }]
    }));
  };

  const removeQuestion = (index) => {
    if (formData.questions.length <= 1) return;
    setFormData(prev => ({
      ...prev,
      questions: prev.questions.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.company || !formData.jobTitle) {
      setError('회사명과 직무명은 필수입니다.');
      return;
    }
    if (formData.questions.some(q => !q.text)) {
      setError('모든 문항을 입력해주세요.');
      return;
    }
    setError('');
    setStep(2);
    setLoadingMessage('프로젝트 생성 중...');
    
    try {
      // 1. 프로젝트 생성 (백엔드에서 백그라운드 분석 자동 시작)
      const result = await projectApi.create(userId, formData);
      
      if (!result.project) {
        throw new Error('프로젝트 생성 실패');
      }
      
      setLoadingMessage('AI가 전체 분석을 수행하고 있습니다... 최대 5분정도 소요될 수 있어요');
      await requestNotificationPermission();      
      // 2. 분석 완료 대기 (폴링)
      const maxWaitTime = 600000; // 최대 10분
      const pollInterval = 3000;  // 3초마다 확인
      const startTime = Date.now();
      
      while (Date.now() - startTime < maxWaitTime) {
        try {
          const status = await projectApi.getAnalysisStatus(result.project.id, userId);
          
          if (status.analysis_status === 'analyzed') {
            setLoadingMessage('분석 완료!');
            sendNotification('딥글 세션이 생성되었어요', `${formData.company} / ${formData.jobTitle} 분석이 완료되었습니다.`);
            setTimeout(() => {
              onCreated(result.project);
            }, 500);
            return;
          }
          
          if (status.analysis_status === 'failed') {
            throw new Error('분석에 실패했습니다. 다시 시도해주세요.');
          }
          
          // 진행 상황 표시
          if (status.analysis_step) {
            setLoadingMessage(`분석 중: ${status.analysis_step}`);
          }
        } catch (pollErr) {
          console.error('폴링 오류:', pollErr);
          // 폴링 오류는 무시하고 계속 시도
        }
        
        await new Promise(resolve => setTimeout(resolve, pollInterval));
      }
      
      // 타임아웃 - 그래도 프로젝트 페이지로 이동 (분석 진행 중 표시)
      setLoadingMessage('분석이 계속 진행 중입니다...');
      setTimeout(() => {
        onCreated(result.project);
      }, 500);
      
    } catch (err) {
      if (err.status === 429) {
        onRateLimit();
      } else {
        setError(err.message || '프로젝트 생성에 실패했습니다.');
        setStep(1);
      }
    }
  };
// 로딩 화면 (분석 중) - 전체화면 버전
if (step === 2) {
  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: '80px',
      right: 0,
      bottom: 0,
      background: '#FBFBFD',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 9999
    }}>
  <div style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '24px'
      }}>
        <p style={{
          color: '#1F2937',
          fontSize: '20px',
          fontWeight: '700',
          margin: 0
        }}>약 5~10분 소요됩니다</p>
        <div style={{
          position: 'relative',
          width: '80px',
          height: '80px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          <svg width="80" height="80" viewBox="0 0 200 200">
            <defs>
              <linearGradient id="loadingGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#9CA3AF" stopOpacity="0.3"/>
                <stop offset="100%" stopColor="#6B7280" stopOpacity="0.3"/>
              </linearGradient>
            </defs>
            <circle cx="100" cy="100" r="80" fill="url(#loadingGradient)" stroke="rgba(107, 114, 128, 0.5)" strokeWidth="2"/>
            <rect x="92" y="40" width="16" height="120" fill="rgba(74, 85, 104, 0.8)" rx="8"/>
            <rect x="40" y="92" width="120" height="16" fill="rgba(74, 85, 104, 0.8)" rx="8"/>
          </svg>
          <div className="pulse-ring pulse-ring-1"></div>
          <div className="pulse-ring pulse-ring-2"></div>
          <div className="pulse-ring pulse-ring-3"></div>
        </div>
        <p style={{
          color: '#4B5563',
          fontSize: '17px',
          fontWeight: '500',
          margin: 0
        }}>{loadingMessage}</p>
      </div>
    </div>
  );
}

return (
  <div style={{
    position: 'fixed',
    top: 0,
    left: '80px',
    right: 0,
    bottom: 0,
    background: '#FBFBFD',
    zIndex: 9999,
    overflowY: 'auto'
  }}>
    <div style={{
      maxWidth: '680px',
      margin: '0 auto',
      padding: '48px 24px'
    }}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '32px'
      }}>
        <h1 style={{ margin: 0, fontSize: '28px', fontWeight: '700' }}>새 딥글 만들기</h1>
        <button 
          onClick={onClose}
          style={{
            background: 'none',
            border: 'none',
            fontSize: '24px',
            cursor: 'pointer',
            color: '#86868B'
          }}
        >×</button>
      </div>
      
      <form onSubmit={handleSubmit}>
        {error && <div className="login-error">{error}</div>}

        <div className="form-row">
          <div className="input-group">
            <label>회사명 *</label>
            <input
              type="text"
              name="company"
              className="input-field"
              value={formData.company}
              onChange={handleChange}
              placeholder="삼성전자"
              required
            />
          </div>
          <div className="input-group">
            <label>직무명 *</label>
            <input
              type="text"
              name="jobTitle"
              className="input-field"
              value={formData.jobTitle}
              onChange={handleChange}
              placeholder="SW개발"
              required
            />
          </div>
        </div>

        <div className="input-group">
          <label>직무 내용</label>
          <textarea
            name="jobTasks"
            className="input-field textarea-field"
            value={formData.jobTasks}
            onChange={handleChange}
            placeholder="주요 업무 내용을 입력하세요"
            rows={3}
          />
        </div>

        <div className="input-group">
          <label>자격 요건</label>
          <textarea
            name="jobRequirements"
            className="input-field textarea-field"
            value={formData.jobRequirements}
            onChange={handleChange}
            placeholder="자격 요건을 입력하세요"
            rows={3}
          />
        </div>

        <div className="input-group">
          <label>이력서 선택</label>
          <select
            name="resumeId"
            className="input-field"
            value={formData.resumeId}
            onChange={handleChange}
          >
            <option value="">이력서를 선택하세요 (선택사항)</option>
            {resumes.map(resume => (
              <option key={resume.id} value={resume.id}>
                {resume.fileName} ({resume.versionName})
              </option>
            ))}
          </select>
        </div>

        <div className="questions-section">
          <label>자소서 문항 *</label>
          {formData.questions.map((q, index) => (
            <div key={index} className="question-row">
              <span className="question-number">{index + 1}</span>
              <input
                type="text"
                className="input-field question-input"
                value={q.text}
                onChange={(e) => handleQuestionChange(index, 'text', e.target.value)}
                placeholder="자소서 문항을 입력하세요"
              />
              <input
                type="number"
                className="input-field word-limit-input"
                value={q.wordLimit}
                onChange={(e) => handleQuestionChange(index, 'wordLimit', e.target.value)}
                placeholder="글자수"
              />
              <span className="word-limit-suffix">자</span>
              {formData.questions.length > 1 && (
                <button
                  type="button"
                  className="remove-question-btn"
                  onClick={() => removeQuestion(index)}
                >
                  ×
                </button>
              )}
            </div>
          ))}
          <button type="button" className="add-question-btn" onClick={addQuestion}>
            + 문항 추가
          </button>
        </div>
        
        <div style={{
          display: 'flex',
          justifyContent: 'flex-end',
          gap: '12px',
          marginTop: '32px'
        }}>
          <button type="button" className="button-secondary" onClick={onClose}>
            취소
          </button>
          <button type="submit" className="button-primary">
            프로젝트 생성
          </button>
        </div>
      </form>
    </div>
  </div>
);
};
export default DashboardPage;